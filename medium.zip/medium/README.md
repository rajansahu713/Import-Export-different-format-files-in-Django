Title: Import Export of different formats files in Django through admin panel.

* Today I came across a django third party library(django-import-export) that allows you to import and export data from admin panel for diffrent format files (csv, json, xls,xml, yaml, tsv) and it is easy to use . and today we are going to explore this liabary and see how it works.

Introductions
* django-import-export is a Django application and library for importing and exporting data with included admin integration.
Today we are going to explore this package and see how it works.

Requirements
```
django
django-import-export
```

Step 1: Project Setup 

Click here (https://docs.python.org/3/tutorial/venv.html) and follow the steps for create the virtual environment and activate the virtual environment.
 
And the install all the package which are mentioned in the requirements.txt file.

Step 2: Create the project
```
django-admin startproject  importexportadmin
```

Step 3: Create the app
```
python manage.py startapp app
```
Note: 

We can create multiple app in the same project but not able to create multiple project in the same project.



Step 4: Register the app and import_export in the settings.py file to collect the static file of it.

```
# settings.py
INSTALLED_APPS = (
    ...
    'app',
    'import_export',
)
```

Step 5: Now everything is setup, move head and create the models file.
```python
#app/models.py
class Report(models.Model):
    id = models.ImageField(primary_key=True)
    title = models.CharField(max_length=100)
    description = models.TextField()
    cost = models.IntegerField()
    create_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title
```
Done with creating model and now run the below command to create the database.

```Python
python manage.py makemigrations
```
And 
```python
python manage.py migrate 
```

We have create tables in the database.

Step 6: Create super user and login to the admin panel.

```python
python manage.py createsuperuser
```
After running the above command you will see the following message.
```
Username (leave blank to use 'rajansahu'): 
Email address: 
Password: 
Password (again): 
```
After entering the username and password you are able to login to the admin panel.
```url
http://127.0.0.1:8000/admin/
```
Now you are not able to see report table in the admin panel as below image.

<img src="image1.png" width=""/>

Step 7: Now we will register the model in the admin panel.

In case we need to first create resource and then register the resource in the admin panel. but for then this just we need to register the models in the admin panel only.

To integrate django-import-export with our Report model, we will create a ModelResource class in resource.py that will describe how this resource can be imported or exported:   

```python
#app/resource.py
from import_export import resources
from .models import Report

class ReportResource(resources.ModelResource):
    class Meta:
        model = Report
```

Now we will integrate this ModelResource with Admin panel

```python
#app/admin.py
from import_export.admin import ImportExportModelAdmin
from django.contrib import admin
from .resource import ReportResource 
from .models import Report
    
class ReportAdmin(ImportExportModelAdmin):
    resource_class = ReportResource
    
admin.site.register(Report, ReportAdmin)
```

Now again login to the admin panel and you will see the report table in the admin panel.

<img src="image2.png" width=""/>

In the above image we can see three buttom on the top right side just below of log out.

1. Import 
2. Export 
3. Add report

Import: When you click on import button, you will able to import file.

<img src="image4.png" width=""/>

* File to import: Choose the file which you want to import.
* Format: Choose the format of the file which you want to import.

Now hit the Summit button it will show preview of data present in csv file as shown in the below image.

<img src="image3.png" width=""/>

Hit the Corfirm import button to import the data.


Export: When you click on export button, you will able to export the file.

* Format: Choose the format of the file which you want to export.

